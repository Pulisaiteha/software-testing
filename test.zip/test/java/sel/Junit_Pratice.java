package sel;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class Junit_Pratice {
	
	 @AfterAll
	static void afterAll() {
			System.out.println("This method runs once after all methods excuted");
		}
	 
	 @BeforeAll
	 static void beforeAll() {
			System.out.println("This method runs once first before starting of all methods");

		 
	 }
	
	
	
	 @BeforeEach
	void before() {
		System.out.println("This method runs every time before other method");
	}
	 
	 @AfterEach
	 void after() {
			System.out.println("This method runs every time after other method");
		}
	 
	
	@Test
	void getd1() {
		System.out.println("Test 1");
	}
	
	@Test
	void getd2() {
		System.out.println("Test 2");
	}
	
	
	@ParameterizedTest
    @ValueSource(strings = {"Hello", "JUnit", "Parameterized Test"})
	void para(String input) {
		System.out.println(input);
	}
	
	@RepeatedTest(5)
	void repeat() {
		System.out.println("This is repetaed test method ");
	}
	@DisplayName("Custom Test Name")
    void customNameTest() {
        System.out.println("Running a test with a custom display name.");
    }

}
