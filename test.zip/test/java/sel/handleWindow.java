package sel;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class handleWindow {

	public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        
        WebDriver driver=new ChromeDriver();
        
        driver.get("https://omayo.blogspot.com/");
        String hedata = driver.findElement(By.xpath("//h2")).getText();
        System.out.print(hedata);
        
        driver.findElement(By.xpath(" //div[@class='widget-content']/p/a[text()='Open a popup window']")).click();
        
        
//        String h3WindowTwo = driver.findElement(By.xpath("//h3")).getText();
//        System.out.println(h3WindowTwo);
        
       String firstPageTitle = driver.getTitle();
//       System.out.println(firstPageTitle);
       
       Set<String> windowIDS = driver.getWindowHandles();
       String h3WindowTwo=null;
       
       for(String s : windowIDS) {
    	   driver.switchTo().window(s);
       
       
       if(!firstPageTitle.equals("omayo (QAFox.com")) {
    	     h3WindowTwo = driver.findElement(By.xpath("//h3")).getText();
           System.out.println(h3WindowTwo);
    	   
       }
       
     }

	}

}
