package sel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Demo {

    public static void main(String[] args) {

         WebDriverManager.chromedriver().setup();
 
         WebDriver driver = new ChromeDriver();

         driver.get("https://in.bookmyshow.com/explore/activities");
         driver.findElement(By.xpath("//input[@class='bwc__sc-1iyhybo-6 ilhhay']")).sendKeys("pushpa");
         driver.close();
         
         driver.findElement(By.xpath("//div[text()='Detect my location']")).click();
         driver.manage().window().maximize();
         driver.manage().window().minimize();
         
        WebElement search= driver.findElement(By.xpath("//input[@id='s']"));
        search.sendKeys("hp");
         
        WebElement searchbutton=driver.findElement(By.xpath("//button[contains(@id,'search')]"));
        searchbutton.click();
         
        WebElement link=driver.findElement(By.linkText("Join our Telegram Group"));
        boolean checklinktext=link.isDisplayed();
        
        if(checklinktext) {
        	System.out.print("True");
        }
        else {
        	System.out.print("False");
        }
      }
}

