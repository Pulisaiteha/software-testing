//package sel;
//
//import java.time.Duration;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//
//import io.github.bonigarcia.wdm.WebDriverManager;
//
//public class ExpectedCondition {
//
//    public static void main(String[] args) {
//        
//        WebDriverManager.chromedriver().setup();
//        
//        WebDriver driver = new ChromeDriver();
//        driver.get("https://omayo.blogspot.com/");
//        
//        // Locate the first button to click
//        WebElement checkbox = driver.findElement(By.xpath("//button[text()='Check this']"));
//        boolean status = checkbox != null;
//        if (status) {
//            System.out.println("CheckBox located");
//        }
//        checkbox.click();
//        
//        // Locate the second button (checkbutton)
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
//        WebElement checkbutton = wait.until(
//            ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='dte']"))
//        );
//        
//        wait.until(ExpectedConditions.elementToBeClickable(checkbutton));
//        
//        // Check if the button is enabled and click it
//        if (checkbutton.isEnabled()) {
//            checkbutton.click();
//            System.out.println("Check button clicked");
//        } else {
//            System.out.println("Check button not clicked");
//        }
//        driver.quit();
//    }
//}
//

package sel;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ExpectedCondition{
	
	public static void main(String[] args) {
      WebDriverManager.chromedriver().setup();

		
		WebDriver driver=new ChromeDriver();
		driver.get("https://omayo.blogspot.com/");
		System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());
		
		WebElement checkbutton=driver.findElement(By.xpath("//button[text()='Check this']"));
		checkbutton.click();
		
		if(!checkbutton.isEnabled())
		{
			System.out.println("Check button not enabled");
		}
		else {
			System.out.println("Check button is enabled");
		}
	
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(15));
		
	       WebElement checkbutton1 = wait.until(
	             ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@id='dte']"))
	         );
	         
	         wait.until(ExpectedConditions.elementToBeClickable(checkbutton1));
		
	         if(!checkbutton1.isEnabled()) {
	        	 System.out.print("Notenabled after15 sec");
	         }
	         else {
	        	 System.out.print("enabled after15 sec");
	         }
		
	}
	
}
