package sel;

import java.awt.Dimension;
import java.awt.geom.Dimension2D;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Commands3 {

	public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        
        WebDriver driver=new ChromeDriver();
        driver.get("https://omayo.blogspot.com/");
        
        driver.manage().window().fullscreen();
        
//        org.openqa.selenium.Dimension d= new Dimension(500,500);
//        driver.manage().window().setSize(d);
		 
		driver.navigate().to("http://selenium143.blogspot.com/");
		
		driver.navigate().back();
		
		driver.navigate().forward();
		
		System.out.println(driver.getPageSource());
		
 
		driver.quit();
        
        WebElement para = driver.findElement(By.xpath("//div[@class='widget Text']/child::div"));
        System.out.println(para.getTagName());
        System.out.println(para.getCssValue("class"));
        
       WebElement search = driver.findElement(By.xpath("input[class='gsc-search-button'"));
       
      String value = search.getAttribute("value");
      System.out.println(value);
      
         
        
 
	}

}
