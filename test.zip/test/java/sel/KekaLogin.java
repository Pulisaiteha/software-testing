package sel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class KekaLogin {

	public static void main(String[] args) {
 
		WebDriverManager.chromedriver().setup();
		
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.keka.com/");
		driver.findElement(By.xpath("//a[@class='text-secondary text-xs mr-40']")).click();
		
		
		WebElement Enteremail=driver.findElement(By.xpath("//input[@id='email']"));
		Enteremail.sendKeys("puli.teja@ict360.com");
		
		WebElement Continue =driver.findElement(By.xpath("//button[contains(@class,'btn btn-primary')]"));
		Continue.click();
		
		
			

	}

}
