package sel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class OmayoBlogspot {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://omayo.blogspot.com/");
		
//		WebElement seleniumLink=driver.findElement(By.linkText("Selenium143"));
//		seleniumLink.click();
		driver.manage().window().maximize();
		
//		driver.findElement(By.id("checkbox1")).click();
		
		WebElement textareafield=driver.findElement(By.id("ta1"));
		textareafield.click();
		textareafield.sendKeys("hi");
 
	}

}
