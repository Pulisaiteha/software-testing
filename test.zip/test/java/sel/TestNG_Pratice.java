package sel;

import org.testng.annotations.Test;
import org.testng.*;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;


public class TestNG_Pratice {
	
	@Test
	void getd() {
		System.out.println("This is first test");
	}
	
	@BeforeSuite
	void beforeSuite() {
		System.out.println("This is beforeSuite test");

	}
	
	@AfterSuite
	void aftersuite()
	{
		System.out.println("This is AfterSuite test");

	}
	

}
