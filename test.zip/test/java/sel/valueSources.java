package sel;

public @interface valueSources {

	String[] strings();

}
