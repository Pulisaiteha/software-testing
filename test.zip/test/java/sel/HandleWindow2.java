package sel;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HandleWindow2 {

	public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        
        WebDriver driver=new ChromeDriver();
        
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4));
        driver.get("https://omayo.blogspot.com/");
        String firstPageID = driver.getWindowHandle();
        
        WebElement linkdata = driver.findElement(By.xpath("//a[text()='Open a popup window']"));
        linkdata.click();
        
        Set<String> windowIDs = driver.getWindowHandles();
       
       for(String IDS : windowIDs) {
    	   
    	   driver.switchTo().window(IDS);
    	   
    	   if(!IDS.equals(firstPageID)) {
    		    WebElement h3data = driver.findElement(By.xpath("//h3"));
    		    System.out.println(h3data.getText());
    		        		   
    	   }
       }
      
      driver.quit();
     
       
       


	}

}
