package sel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;


public class TestNG_ex1 {
 
	
	@Test
	void alert() {
        WebDriverManager.chromedriver().setup();

 		WebDriver driver = new ChromeDriver();
		
 		driver.get("https://www.facebook.com/");
 		WebElement searchBox = driver.findElement(By.xpath("//div[@class='_6lux']/input"));
		
		Actions action=new Actions(driver);
		action.contextClick(searchBox).build().perform();

	}

}
