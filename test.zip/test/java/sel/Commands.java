package sel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Commands {

	public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();

		
		WebDriver driver=new ChromeDriver();
		driver.get("https://omayo.blogspot.com/");
		WebElement textClear=driver.findElement(By.xpath("//input[@value='Selenium WebDriver']"));
		textClear.clear();
 		
		WebElement omayotext=driver.findElement(By.xpath("//h1[contains(text(),'omayo')]"));
		String GetText = omayotext.getText();
		System.out.println(GetText);
		
		String TagName = omayotext.getTagName();
		System.out.println("This is tagname" +" "+TagName);
		
//		driver.findElement(By.xpath("//div[@id='HTML37']//p"));
		
		System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());

 
	}

}
